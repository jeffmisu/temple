
#include "ComponentLambda.h"

#include "ComponentBoard.h"
#include "ComponentApp.h"
#include <fstream>
#include <iostream>

ComponentLambda::ComponentLambda()
{
  sPatchIn pi;
  pi.comp = NULL;
  pi.dynamic = true;
  pi.name = "Expression";
  pi.type = CT_NONE;

  sPatchOut po[2];

  po[0].dynamic = false;
  po[0].name = "Value";
  po[0].type = CT_NONE;
  po[0].value = NULL;

  po[1].dynamic = true;
  po[1].name = "Bound expression";
  po[1].type = CT_NONE;
  po[1].value = NULL;

  InitializePatches(&pi, 1, po, 2);

  SetVariableType(CT_NONE);
}

ComponentLambda::~ComponentLambda()
{
}

void ComponentLambda::OnRightClicked()
{
  rwContextMenu *cm = new rwContextMenu(Component::m_position, rwFUNCTOR(OnSelection), this);
  cm->AddChoice("Real", (void *)CT_DOUBLE);
  cm->AddChoice("Boolean", (void *)CT_BOOL);
  cm->AddChoice("None", (void *)CT_NONE);
/*
  rwTextBox *t = new rwTextBox(m_position, rwFUNCTOR(OnTextEntered), this);
  t->SetAlphanumericFilter();
  t->SetText(m_name);
*/
}
/*
void ComponentLambda::OnTextEntered(ComponentLambda *caller, rwTextBoxEvent &e)
{
  if (e.type == rwTEXT_RETURN)
    caller->m_name = e.text;
}
*/
void ComponentLambda::OnSelection(ComponentLambda *caller, rwContextMenuEvent &e)
{
  if (e.type == rwCONTEXT_SELECT)
    caller->SetVariableType(*(ComponentType *)&e.data);
}

void ComponentLambda::SetVariableType(ComponentType type)
{
  if (type != m_outputs[0].type)
  {
    std::cout << m_outputs[0].clients.size() << " clients" << std::endl;
    for (size_t i = 0; i < m_outputs[0].clients.size(); i++)
      m_outputs[0].clients[i]->RemoveInput(this, false);
    m_outputs[0].clients.clear();
    deleteValue(m_outputs[0].value, m_outputs[0].type);
    m_outputs[0].type = type;
    m_outputs[0].value = newValue(type);
  }
}

void ComponentLambda::Apply()
{
  // Push the current value to history
  m_history.push_front(newValue(m_outputs[0].type));
  assignValue(m_history[0], m_outputs[0].value, m_outputs[0].type);

  // This is rather reckless at the moment, but eventually we'll type-check. Right?
  // So, we pop a value from the global environment, and tell the associated app node
  // which lambda expression ended up using it (this one).
  sApplication app = m_host->PopApps();
  assignValue(m_outputs[0].value, app.value, m_inputs[0].type);
  assignValue(m_outputs[1].value, app.value, m_inputs[0].type);
  app.app->PushHistory(this);

  //std::cout << "Applying " << getValueString(m_outputs[0].value, m_inputs[0].type) << " to " << m_name << std::endl;

  if (m_inputs[0].comp != NULL)
    m_inputs[0].comp->Evaluate(m_inputs[0].index);

  assignValue(m_outputs[0].value, m_inputs[0].value, m_inputs[0].type);
  assignValue(m_outputs[1].value, m_inputs[0].value, m_inputs[0].type);

  //std::cout << "Application resulted in " << getValueString(m_outputs[0].value, m_inputs[0].type) << std::endl;
}

void ComponentLambda::Unapply()
{
  // Pop from the value back from our history
  //std::cout << "Was " << getValueString(m_outputs[0].value, m_inputs[0].type);
  assignValue(m_outputs[0].value, m_history[0], m_inputs[0].type);
  assignValue(m_outputs[1].value, m_history[0], m_inputs[0].type);
  //std::cout << ", now " << getValueString(m_outputs[0].value, m_inputs[0].type) << std::endl;
  deleteValue(m_history[0], m_inputs[0].type);
  m_history.pop_front();
}

void ComponentLambda::Evaluate(int index)
{
  if (index == 1)
    Apply();
}

std::string ComponentLambda::GetNodeType()
{
  std::stringstream t;
  //t << "Lambda (" << m_name << ")";
  t << "Lambda";

  return t.str();
}

void ComponentLambda::ToFile(std::ostream &out)
{
  out << "Lambda";
  WriteDefaultParams(out);
  out << m_outputs[0].type;
  //out << m_name;
}

Component *ComponentLambda::FromFile(std::istream &in)
{
  ComponentLambda *c = new ComponentLambda();
  c->ReadDefaultParams(in);
  int type;
  in >> type;
  c->SetVariableType((ComponentType)type);
  //in.ignore(1, ' ');  // Ignore the space before the name
  //getline(in, c->m_name);

  return c;
}

Component *ComponentLambda::Create()
{
  return new ComponentLambda();
}
