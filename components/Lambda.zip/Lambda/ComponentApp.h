
#ifndef COMPONENTAPP_H
#define COMPONENTAPP_H

#include "../../Component.h"
#include <deque>

// Important note!
// Because of how applications are performed, the only way to guarantee that
// you'll get the correct result of an App node is to read its output value
// immediately after calling Evaluate(). If you call Evaluate() on another
// node first, that node might reuse the same App node and therefore change
// its result.

class ComponentLambda;

//CMP_NAME=App

class ComponentApp: public Component
{
  protected:
  std::deque<ComponentLambda *> m_history;

  public:
  ComponentApp();
  ~ComponentApp();

  void SetInput(size_t ind, Component *node, int patchInd);

  void PushHistory(ComponentLambda *exp);

  void Evaluate(int index = 0);

  std::string GetNodeType();

  void ToFile(std::ostream &out);
  static Component *FromFile(std::istream &in);
  static Component *Create();
};

#endif
