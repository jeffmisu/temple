
#include "ComponentInc.h"

#include <fstream>

ComponentInc::ComponentInc()
{
  sPatchIn pi[2];
  pi[0].comp = NULL;
  pi[0].dynamic = false;
  pi[0].name = "Delta";
  pi[0].type = CT_DOUBLE;

  pi[1].comp = NULL;
  pi[1].dynamic = false;
  pi[1].name = "Reset";
  pi[1].type = CT_DOUBLE;

  Component::InitializePatches(pi, 2, CT_DOUBLE);
}

ComponentInc::~ComponentInc()
{
}

ComponentInc &ComponentInc::operator=(const ComponentInc &s)
{
  Component::operator=(s);

  return *this;
}

void ComponentInc::SetValue(double value)
{
  assignValue(m_outputs[0].value, &value, m_outputs[0].type);
}

void ComponentInc::Evaluate(int index)
{
  double inc = 1.0, reset = 0.0;
  if (m_inputs[0].comp != NULL)
    inc = *(double *)m_inputs[0].value;
  if (m_inputs[1].comp != NULL)
    reset = *(double *)m_inputs[1].value;
  
  if ((*(double *)m_outputs[0].value += inc) >= reset && reset > 0.0)
    *(double *)m_outputs[0].value = 0;
}

void ComponentInc::OnRightClicked()
{
  rwTextBox *t = new rwTextBox(Component::m_position, rwFUNCTOR(OnTextEntered), this);
  t->SetNumericFilter();
  t->SetText("");
}

void ComponentInc::OnTextEntered(ComponentInc *caller, rwTextBoxEvent &e)
{
  if (e.type == rwTEXT_RETURN)
    sscanf(e.text.c_str(), "%lf", (double *)caller->m_outputs[0].value);
}

std::string ComponentInc::GetNodeType()
{
  std::stringstream t;
  t << "Inc (" << getValueString(this->m_outputs[0].value, this->m_outputs[0].type) << ")";

  return t.str();
}

void ComponentInc::ToFile(std::ostream &out)
{
  out << "Inc";
  WriteDefaultParams(out);
  out << *(double *)m_outputs[0].value;
}

Component *ComponentInc::FromFile(std::istream &in)
{
  ComponentInc *c = new ComponentInc();
  c->ReadDefaultParams(in);
  in >> *(double *)c->m_outputs[0].value;

  return c;
}

Component *ComponentInc::Create()
{
  return new ComponentInc();
}
