
#include "ComponentApp.h"

#include "ComponentBoard.h"
#include "ComponentLambda.h"
#include <fstream>
#include <iostream>

ComponentApp::ComponentApp()
{
  sPatchIn pi[2];

  pi[0].comp = NULL;
  pi[0].dynamic = true;
  pi[0].name = "Bound expression";
  pi[0].type = CT_NONE;

  pi[1].comp = NULL;
  // Input 1 is "dynamic", but not in the way the Component class expects,
  // so we don't mark it as such.
  pi[1].dynamic = false;
  pi[1].name = "Value";
  pi[1].type = CT_NONE;

  sPatchOut po;
  po.dynamic = true;
  po.name = "Value";
  po.type = CT_NONE;

  InitializePatches(pi, 2, &po, 1);
}

ComponentApp::~ComponentApp()
{
}

void ComponentApp::SetInput(size_t ind, Component *node, int patchInd)
{
  if (ind == 0)
  {
    Component::SetInput(ind, node, patchInd);
    return;
  }
  else if (ind != 1)
    return;

  // Input 1 for App components is kind of a special case. Its type is
  // not necessarily constrained by the type of input 0, nor does it
  // influence the type of the output (under our incomplete typing system).
  // So, we handle it here.

  if (node != NULL)
  {
    if (node->GetOutputs()[patchInd].type == CT_NONE)
      return;
    m_inputs[ind].value = node->GetOutputs()[patchInd].value;
    m_inputs[ind].type = node->GetOutputs()[patchInd].type;
    node->AddOutput(this, patchInd);
  }
  else
  {
    m_inputs[ind].value = NULL;
    m_inputs[ind].type = CT_NONE;
  }
  m_inputs[ind].comp = node;
  m_inputs[ind].index = patchInd;

  return;

  if (ind >= m_inputs.size())
    return;

  if (m_inputs[ind].comp != NULL)
  {
    m_inputs[ind].comp->RemoveOutput(this, false);
    m_inputs[ind].comp = NULL;
  }

  ComponentType type = CT_NONE;
  if (node != NULL)
    type = node->GetOutputs()[patchInd].type;

  bool valid = node != NULL;

  if (valid)
  {
    m_inputs[ind].type = type;
    m_inputs[ind].comp = node;
    m_inputs[ind].index = patchInd;
    node->AddOutput(this, patchInd);
  }
  else
  {
    m_inputs[ind].type = CT_NONE;
    m_inputs[ind].comp = NULL;
    m_inputs[ind].index = -1;
  }

  if (ind == 1 && valid)
  {
    deleteValue(m_outputs[patchInd].value, m_outputs[patchInd].type);
    m_outputs[patchInd].type = type;
    m_outputs[patchInd].value = newValue(m_outputs[patchInd].type);
    if (valid)
      m_inputs[ind].value = node->GetOutputs()[patchInd].value;
  }
  else if (valid)
    // Danger: If you hook the lambda into the app before hooking up
    // an input to the lambda, this won't be an accurate pointer.
    m_inputs[ind].value = node->GetOutputs()[patchInd].value;
}

void ComponentApp::PushHistory(ComponentLambda *exp)
{
  m_history.push_front(exp);
}

void ComponentApp::Evaluate(int index)
{
  if (m_inputs[0].comp == NULL || m_inputs[1].comp == NULL)
    return;

  m_inputs[1].comp->Evaluate(m_inputs[1].index);

  //std::cout << "Pushing " << getValueString(m_inputs[1].value, m_inputs[1].type) << std::endl;

  sApplication app;
  app.value = m_inputs[1].value;
  app.app = this;
  m_host->PushApps(app);
  m_inputs[0].comp->Evaluate(m_inputs[0].index);

  // The type should be determined more intelligently, of course, but for now...
  assignValue(m_outputs[0].value, m_inputs[0].value, CT_DOUBLE);

  m_history[0]->Unapply();
  m_history.pop_front();
}

std::string ComponentApp::GetNodeType()
{
  std::stringstream t;
  t << "App";

  return t.str();
}

void ComponentApp::ToFile(std::ostream &out)
{
  out << "App";
  WriteDefaultParams(out);
}

Component *ComponentApp::FromFile(std::istream &in)
{
  ComponentApp *c = new ComponentApp();
  c->ReadDefaultParams(in);

  return c;
}

Component *ComponentApp::Create()
{
  return new ComponentApp();
}
