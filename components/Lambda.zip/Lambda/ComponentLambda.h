
#ifndef COMPONENTLAMBDA_H
#define COMPONENTLAMBDA_H

#include "../../Component.h"
#include <deque>

// The Lambda and App classes implement a kind of lambda calculus.
// What's called a 'Lambda' here is really just a representation of a bound
// variable. It has two outputs - the first just reads the value of the
// variable while the second asks it to pop a new value from the environment
// stack (stored in a ComponentBoard object) and Evaluate(). The second output
// should always eventually come to an App node.

//CMP_NAME=Lambda

class ComponentLambda: public Component
{
  protected:
  std::string m_name;

  // A stack of the values applied to this lambda expression, to allow
  // recursion
  std::deque<void *> m_history;

  public:
  ComponentLambda();
  ~ComponentLambda();

  //void SetInput(size_t ind, Component *node, int patchInd);
  void SetVariableType(ComponentType type);

  void Apply();
  void Unapply();
  void Evaluate(int index = 0);

  void OnRightClicked();
  //static void OnTextEntered(ComponentLambda *caller, rwTextBoxEvent &e);
  static void OnSelection(ComponentLambda *caller, rwContextMenuEvent &e);

  std::string GetNodeType();

  void ToFile(std::ostream &out);
  static Component *FromFile(std::istream &in);
  static Component *Create();
};

#endif
